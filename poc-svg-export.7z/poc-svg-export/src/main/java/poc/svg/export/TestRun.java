package poc.svg.export;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import poc.svg.export.api.ImageDataConverter;
import poc.svg.export.api.MarkerRenderer;
import poc.svg.export.api.SvgExporter;
import poc.svg.export.impl.ImageDataConverterImpl;
import poc.svg.export.impl.MarkerRendererImpl;
import poc.svg.export.impl.SvgExporterImpl;
import poc.svg.export.model.AnnotatedImage;
import poc.svg.export.model.ImageData;
import poc.svg.export.model.MarkerData;
import poc.svg.export.model.MarkerData.Colour;
import poc.svg.export.model.MarkerData.Shape;
import poc.svg.export.model.ViewBox;

public class TestRun {

  private static final String[] TAGS = new String[] {"todo", "important", "door", "minor", "major", "alarm", "hazard", "leaking"};
  
  private static final String[] WORDS = new String[] {"flibble", "banana", "toast", "for", "James", "damp", "aroma", "settee", "slimy", "the", "a"};
  
  private static final String[] NAMES = new String[] {"Peter", "John", "Alan", "Ellen", "JR", "Bobby", "Junior", "The Great", "The Mysterious"};
  
  private static final String[] IDS = new String[] {"AXFF", "-", "1342-2343", "4434", "HR/2", "AB#2", "LLL-BB", "901", "6969"};
  
  private static final String[] DATES = new String[] {"Teatime", "A week last Thursday", "3rd March 1904", "Tommorrow evening", "Midnight", "12 June 2029", "5 March 1981", "29 Feb 1999", "1 Jan 2001"};
  
  public static void main(String[] args) throws IOException {

    ImageDataConverter converter = new ImageDataConverterImpl();
    MarkerRenderer renderer = new MarkerRendererImpl();
    SvgExporter exporter = new SvgExporterImpl(converter, renderer);
    
    // TODO - really load image data
    //        in this case, we know the image details
    ImageData mockImageData = new ImageData(2896, 2048, "image/png");
    
    Resource resource = new ClassPathResource("0_g2emrupxrcm_0_2.png");
    AnnotatedImage image = new AnnotatedImage(resource, ViewBox.fromImageData(mockImageData, 1000d));
    image.setImageData(mockImageData);
    
    File folder = new File("C:\\temp");
    String filename = "poc_svg_export.svg";
    
    addRandomMarkers(image, 20);
    
    Optional<File> result = exporter.export(image, folder, filename);
    
    if (result.isPresent()) {
      System.out.println("Written file : " + result.get());
    }
    else {
      System.err.println("No file written");
    }
  }

  private static void addRandomMarkers(AnnotatedImage image, int numMarkers) {
    int numColours = Colour.values().length;
    int numShapes = Shape.values().length;
    
    for (int i = 0; i< numMarkers; i++) {
      MarkerData m = new MarkerData("marker_" + (i+1000));
      m.setColour(Colour.values()[i % numColours]);
      m.setShape(Shape.values()[i % numShapes]);
      m.setX(randomCoord());
      m.setY(randomCoord());
      m.setDescription("Random Marker " + i + " at " + m.getX() + "%, " + m.getY() +"%");
      
      m.getTags().addAll( randomElements(TAGS, 3) );
      m.getAttributes().put("ASSET_ID", randomString(IDS, 4, ""));
      m.getAttributes().put("VISITED", randomString(DATES, 1, ""));
      m.getAttributes().put("DESCRIPTION", randomString(WORDS, 4, " "));
      m.getAttributes().put("OPERATIVE", randomString(NAMES, 2, " "));
      
      image.getMarkers().add(m);
    }
  }

  private static String randomString(String[] values, int numElements, String separator) {
    return randomElements(values, numElements).stream().collect(Collectors.joining(separator));
  }
  
  private static List<String> randomElements(String[] values, int numElements) {
    List<String> r = new ArrayList<String>();
    for (int i = 0; i < numElements; i++) {
      r.add(randomElement(values));
    }
    return r;
  }

  private static String randomElement(String[] values) {
    int i = (int)Math.round(Math.floor(Math.random()*values.length));
    return values[i];
  }

  private static Double randomCoord() {
    return (Math.random() * 70) + 15;
  }

}
