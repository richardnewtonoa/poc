package poc.svg.export.model;

import lombok.Data;

@Data
public class ImageData {
  private final int width;
  private final int height;
  private final String mimeType;
}
