package poc.svg.export.api;

import java.util.Optional;

import org.jdom2.Element;

import poc.svg.export.model.MarkerData;
import poc.svg.export.model.ViewBox;

public interface MarkerRenderer {
  Optional<Element> render(ViewBox viewBox, MarkerData marker);
}
