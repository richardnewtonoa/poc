package poc.svg.export.impl;

import java.util.Optional;

import org.jdom2.Attribute;
import org.jdom2.Element;
import org.jdom2.Namespace;

import poc.svg.export.api.MarkerRenderer;
import poc.svg.export.api.SvgExporter;
import poc.svg.export.model.MarkerData;
import poc.svg.export.model.MarkerData.Shape;
import poc.svg.export.model.ViewBox;

public class MarkerRendererImpl implements MarkerRenderer {
  
  private static final Namespace nsSvg = Namespace.getNamespace("svg", SvgExporter.SVG_NAMESPACE);
  private static final Namespace nsMeta = Namespace.getNamespace("jm", "http://jm.oneadvanced.com/annotations/1.0");
  @Override
  public Optional<Element> render(ViewBox viewBox, MarkerData marker) {
    if ((marker == null) || marker.isInvalid()) { return Optional.empty(); } 
    
    if (marker.getShape() == Shape.CIRCLE) {
      return Optional.of(circle(viewBox, marker));
    }
    
    if (marker.getShape() == Shape.SQUARE) {
      return Optional.of(square(viewBox, marker));
    }
    
    return Optional.empty();
  }

  private Element circle(ViewBox viewBox, MarkerData marker) {
/* JS code
    var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute("cx", (xPct * scaleX));
    circle.setAttribute("cy", (yPct * scaleY));
    circle.setAttribute("r", halfScale);     
 */
    Element g = group(marker);
    
    Element c = new Element("circle", nsSvg);
    c.setAttribute("cx", Double.toString(scaleX(viewBox, marker.getX())));
    c.setAttribute("cy", Double.toString(scaleY(viewBox, marker.getY())));
    c.setAttribute("r", Double.toString(halfScale(viewBox)));
    
    applyStyles(c, marker);
    addDescription(c, marker);
    
    g.addContent(c);
    
    return g;
  }

  private Element group(MarkerData marker) {
    Element g = new Element("g", nsSvg);
    g.addNamespaceDeclaration(nsMeta);
    
    g.setAttribute("id", marker.getId());
    
    g.addContent( metadata(marker) );

    return g;
  }

  private Element metadata(MarkerData marker) {
    Element m = new Element("metadata", nsSvg);
    
    addTextMetaData(m, "markerId", marker.getId());
    addTextMetaData(m, "description", marker.getDescription());
    addTextMetaData(m, "x", marker.getX());
    addTextMetaData(m, "y", marker.getY());
    addTextMetaData(m, "shape", marker.getShape());
    addTextMetaData(m, "colour", marker.getColour());
    
    for (String tag : marker.getTags()) {
      addTextMetaData(m, "tag", tag);
    }
    
    for (String name : marker.getAttributes().keySet()) {
      addTextMetaData(m, "attribute", marker.getAttributes().get(name), new Attribute("name", name));
    }
    return m;
  }

  private void addTextMetaData(Element metaEl, String elName, Object elText, Attribute... attributes) {
    if (elText != null) {
      Element el = new Element(elName, nsMeta);
      el.setText(elText.toString());
      
      for (Attribute attr : attributes) {
        el.setAttribute(attr);
      }
      
      metaEl.addContent(el);
    }
  }

  private double scaleX(ViewBox viewBox, double x) {
    return (viewBox.getWidth() / 100d) * x;
  }

  private double scaleY(ViewBox viewBox, double y) {
    return (viewBox.getHeight() / 100d) * y;
  }  
  
  private double scale(ViewBox viewBox, double v) {
    return (viewBox.getMaximal() / 100d) * v;
  }  
  
  private double halfScale(ViewBox viewBox) {
    return scale(viewBox, 0.5d);
  }  
    
  private Element square(ViewBox viewBox, MarkerData marker) {
/* JS code
    var rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute("x", (xPct * scaleX) - halfScale);
    rect.setAttribute("y", (yPct * scaleY) - halfScale);
    rect.setAttribute("width", scaleX);
    rect.setAttribute("height", scaleX);
    rect.setAttribute("rx", (scaleX/10)); 
 */
    Element g = group(marker);
    
    Element r = new Element("rect", nsSvg);
    r.setAttribute("x", Double.toString(scaleX(viewBox, marker.getX()) - halfScale(viewBox)));
    r.setAttribute("y", Double.toString(scaleY(viewBox, marker.getY()) - halfScale(viewBox)));
    r.setAttribute("width", Double.toString(scaleX(viewBox, 1d)));
    r.setAttribute("height", Double.toString(scaleX(viewBox, 1d)));
    r.setAttribute("rx", Double.toString(scaleX(viewBox, 0.1d)));
    
    applyStyles(r, marker);
    addDescription(r, marker);
    
    g.addContent(r);
    
    return g;    
  }

  private void applyStyles(Element el, MarkerData marker) {
    StringBuilder styles = new StringBuilder();
    
    styles.append("fill: ").append(marker.getColour().name()).append("; opacity: 0.75;");
    
    if (styles.length() > 0) {
      el.setAttribute("style", styles.toString());
    }
  }

  private void addDescription(Element e, MarkerData marker) {
    if (marker.getDescription() != null) {
      Element title = new Element("title", nsSvg);
      title.setText(marker.getDescription());
      e.addContent(title);
    }
  }
}
