package poc.svg.export.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.core.io.Resource;

import lombok.Data;

@Data
public class AnnotatedImage {
  private final Resource image;
  private ImageData imageData = null;
  private final ViewBox viewBox;
  private final List<MarkerData> markers = new ArrayList<MarkerData>();
  
  public boolean populateImageData(Function<Resource, Optional<ImageData>> imageDataFunction) {
    synchronized(this) {
      if (imageData != null) {
        return true;
      }
      
      Optional<ImageData> loaded = imageDataFunction.apply(image);
      if (!loaded.isPresent()) {
        return false;
      }
      else {
        imageData = loaded.get();
        return true;
      }
    }
  }
}
