package poc.svg.export.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import lombok.Data;

@Data
public class MarkerData {
  public static enum Colour { red, green, blue };
  public static enum Shape { CIRCLE, SQUARE };
  
  private final String id;
  private Colour colour;
  private Shape shape;
  private Double x;
  private Double y;
  private String description;
  private final Set<String> tags = new HashSet<String>();
  private final Map<String,String> attributes = new HashMap<>();
  
  public boolean isInvalid() {
    return (colour == null)
        || (shape == null)
        || (x == null)
        || (y == null);
  }
}
