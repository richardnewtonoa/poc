package poc.svg.export.model;

import lombok.Data;

@Data
public class ViewBox {
  private final double width;
  private final double height;
  
  public String asSpec() {
    return "0 0 " + width + " " + height;
  }

  public double getMaximal() {
    return (width > height) ? width : height;
  }

  public static ViewBox fromImageData(ImageData imageData, double maximal) {
    if (imageData.getWidth() > imageData.getHeight()) {
      // using width as maximal
      return new ViewBox(maximal, scale(imageData.getHeight(), imageData.getWidth(), maximal));     
    }
    else {
      // using height as maximal
      return new ViewBox(scale(imageData.getWidth(), imageData.getHeight(), maximal), maximal);
    }
  }

  private static double scale(int toScale, int unscaledMax, double maximal) {
    // e.g. unscaledMax = 250, maximal = 100
    //    toScale = 250 -> result = 100
    //    toScale = 125 -> result = 50
    return (toScale * maximal) / unscaledMax;
  }
}
