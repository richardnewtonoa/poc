package poc.svg.export.impl;

import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Base64;
import java.util.Optional;

import org.springframework.core.io.Resource;

import poc.svg.export.api.ImageDataConverter;
import poc.svg.export.model.AnnotatedImage;
import poc.svg.export.model.ImageData;

public class ImageDataConverterImpl implements ImageDataConverter {

  @Override
  public Optional<String> base64DataUrl(AnnotatedImage image) {
    // e.g.  
    //      data:image/jpeg;charset=utf-8;base64,
    final StringBuilder sb = new StringBuilder();
    sb.append("data:");
    sb.append(image.getImageData().getMimeType());
    sb.append(";base64,");
    
    boolean readData = getBase64Data(sb, image.getImage());
    
    if (!readData) {
      return Optional.empty();
    }
    else {
      return Optional.of(sb.toString());
    }
  }

  private boolean getBase64Data(StringBuilder sb, Resource image) {
    final PipedInputStream pipeIs = new PipedInputStream(100);
    PipedOutputStream pipeOs = null;
    BufferedInputStream bis = null;
    
    try {
      pipeOs = new PipedOutputStream(pipeIs);
      
      System.out.println("Opening image ...");
      bis = new BufferedInputStream(image.getInputStream());
      
      // as data is converted to Base64, we append it to the String Builder
      Thread pipeThread = new Thread() {
        @Override
        public void run() {
          System.out.println("Reading Base64 bytes");
          int count = 0;
          int b = 0;
          try {
            while (b >= 0) {
              b = pipeIs.read();
              if (b >= 0) {
                sb.append(new String(new byte[] {(byte)b}, "US-ASCII"));
                
                count++;
                if (count % 10000 == 0) {
                  System.out.println("o="+count);
                }
              }
            }
            System.out.println("o=done.");
          }
          catch (Exception e) {
            throw new RuntimeException(e);
          }
        }
      };
      
      pipeThread.start();
      
      
      System.out.println("Reading and writing image data through Base64 encoder ...");
      final OutputStream b64os = Base64.getEncoder().wrap(pipeOs);
      int b = 0;
      int count = 0;
      while (b >= 0) {
        b = bis.read();
        if (b >= 0) {
          b64os.write(b);
          
          count++;
          if (count % 10000 == 0) {
            System.out.println("i="+count);
          }
        }
      }
      b64os.close();
      System.out.println("i=done.");
      
      pipeThread.join();
      System.out.println("All done");
      return true;
    }
    catch (Exception e) {
      System.err.println("Error loading image data");
      e.printStackTrace();
      return false;
    }
    finally {
      if (pipeIs != null) { try { pipeIs.close(); } catch (Exception ignore) {} }
      if (pipeOs != null) { try { pipeOs.close(); } catch (Exception ignore) {} }
      if (bis != null) { try { bis.close(); } catch (Exception ignore) {} }
    }
 
  }

  private String getExtension(Resource image) {
    // TODO : dummy
    return "png";
  }

  @Override
  public Optional<ImageData> loadImageData(Resource image) {
    return Optional.empty();
  }

}
