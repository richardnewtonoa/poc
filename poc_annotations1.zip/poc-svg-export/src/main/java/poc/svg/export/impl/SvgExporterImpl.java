package poc.svg.export.impl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Optional;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.Namespace;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import poc.svg.export.api.ImageDataConverter;
import poc.svg.export.api.MarkerRenderer;
import poc.svg.export.api.SvgExporter;
import poc.svg.export.model.AnnotatedImage;
import poc.svg.export.model.MarkerData;

public class SvgExporterImpl implements SvgExporter {

  private static final Namespace nsSvg = Namespace.getNamespace("svg", SvgExporter.SVG_NAMESPACE);
  
  private final ImageDataConverter converter;
  private final MarkerRenderer renderer;
  
  public SvgExporterImpl(ImageDataConverter converter, MarkerRenderer renderer) {
    super();
    this.converter = converter;
    this.renderer = renderer;
  }

  @Override
  public Optional<File> export(AnnotatedImage imageData, File folder, String filename) throws IOException {

    if ((imageData == null) || (folder == null) || (filename == null)) { 
      return Optional.empty();
    }
    
    if (!folder.exists() || !folder.isDirectory() || !folder.canWrite()) {
      throw new RuntimeException("Folder does not exist / is not writeable : " + folder.getAbsolutePath());
    }
    
    // load meta data if we need to
    if (!imageData.populateImageData((img)->converter.loadImageData(img))) {
      throw new RuntimeException("Unable to load image data : " + imageData.getImage());
    }
    
    Element svg = createSvgElement(imageData);
    
    File targetFile = new File(folder, filename);
    writeSvg(targetFile, svg);
    
    return Optional.of(targetFile);
  }

  private Element createSvgElement(AnnotatedImage image) {
    // root element
    Element svgEl = new Element("svg", nsSvg);
    svgEl.setAttribute("width", Integer.toString(image.getImageData().getWidth()));
    svgEl.setAttribute("height", Integer.toString(image.getImageData().getHeight()));
    svgEl.setAttribute("viewBox", image.getViewBox().asSpec());
    
    Optional<Element> imageEl = createImageElement(image);
    if (imageEl.isPresent()) {
      svgEl.addContent(imageEl.get());
    }
    
    for (MarkerData marker : image.getMarkers()) {
      Optional<Element> markerEl = renderer.render(image.getViewBox(), marker);
      if (markerEl.isPresent()) {
        svgEl.addContent(markerEl.get());
      }
    }
    
    return svgEl;
  }

  private Optional<Element> createImageElement(AnnotatedImage image) {
    
    Optional<String> dataRef = getDataRef(image);
    if (!dataRef.isPresent()) {
      return Optional.empty();
    }
    
    Element imgEl = new Element("image", nsSvg);
    
    imgEl.setAttribute("x", "0");
    imgEl.setAttribute("y", "0");
    imgEl.setAttribute("preserveAspectRatio", "");
    imgEl.setAttribute("href", dataRef.get());
    imgEl.setAttribute("style", "opacity:0.75");
    imgEl.setAttribute("width", Double.toString(image.getViewBox().getWidth()));
    
    return Optional.of(imgEl);
  }

  private Optional<String> getDataRef(AnnotatedImage image) {
    return converter.base64DataUrl(image);
  }

  private void writeSvg(File targetFile, Element svg) throws IOException {
    Document doc = new Document(svg);
    XMLOutputter o = new XMLOutputter(Format.getPrettyFormat());
    try (FileWriter fw = new FileWriter(targetFile)) {
      try (BufferedWriter writer = new BufferedWriter(fw)) {
        o.output(doc, writer);
      }
    }
  }

}
