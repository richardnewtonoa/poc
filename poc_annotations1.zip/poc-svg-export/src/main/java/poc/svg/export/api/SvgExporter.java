package poc.svg.export.api;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

import poc.svg.export.model.AnnotatedImage;

public interface SvgExporter {
  
  public static final String SVG_NAMESPACE = "http://www.w3.org/2000/svg";

  Optional<File> export(AnnotatedImage imageData, File folder, String filename) throws IOException;
}
