package poc.svg.export.api;

import java.util.Optional;

import org.springframework.core.io.Resource;

import poc.svg.export.model.AnnotatedImage;
import poc.svg.export.model.ImageData;

public interface ImageDataConverter {
  Optional<String> base64DataUrl(AnnotatedImage image);
  
  Optional<ImageData> loadImageData(Resource image);
}
